# repo_VIII
addon personal

Este es un addon para Kodi que permite explorar y ver películas de dominio público desde Archive.org.

## Características
- Busca películas de dominio público.
- Reproduce directamente desde Archive.org.
